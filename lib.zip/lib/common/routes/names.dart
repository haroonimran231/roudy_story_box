class RouteNames {
  static const String splashPage = '/';
  static const String register = '/register';
  static const String authentication = '/authentication';
  static const String home = '/home';
  static const String connection = '/connection';
  static const String userinfo = '/userinfo';
  static const String messages = '/messages';
}
