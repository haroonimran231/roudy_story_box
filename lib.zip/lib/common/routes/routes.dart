
// import 'package:get/get.dart';

// import 'names.dart';

// // import 'index.dart';

// class AppRoutes {
//   static const String splash = RouteNames.splashPage;
//   // static const String register = RouteNames.register;
//   // static const String authentication = RouteNames.authentication;
//   // static const String home = RouteNames.home;
//   // static const String connection = RouteNames.connection;
//   // static const String userinfo = RouteNames.userinfo;
//   // static const String messages = RouteNames.messages;

//   static List<GetPage> pages = [
//     GetPage(
//         name: splashPage,
//         page: () => const onBoarding1(),
//         // binding: SplashBindings()),
//     // GetPage(
//     //     name: register,
//     //     page: () => const RegisterView(),
//     //     binding: RegisterBindings()),
//     // GetPage(
//     //     name: connection,
//     //     page: () => const ConnectivityCheckView(),
//     //     binding: ConnectivityCheckBindings()),
//     // GetPage(
//     //     name: authentication,
//     //     page: () => const AuthView(),
//     //     binding: AuthBindings()),
//     // GetPage(
//     //     name: userinfo,
//     //     page: () => const UserInfoView(),
//     //     binding: UserInfoBindings()),
//     // GetPage(
//     //   name: home,
//     //   page: () => const HomeView(),
//     //   binding: HomeBindings(),
//     // ),
//     // GetPage(
//     //     name: messages,
//     //     page: () => const MessageView(),
//     //     binding: MessageBindings())
//     ),
//   ];
// }